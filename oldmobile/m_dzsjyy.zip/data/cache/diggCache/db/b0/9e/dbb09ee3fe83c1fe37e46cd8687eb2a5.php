<?php exit('dedecms');?>
a:2:{s:4:"data";s:0:"";s:7:"timeout";i:0;}