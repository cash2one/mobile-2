<?php exit('dedecms');?>
a:2:{s:4:"data";a:1:{s:5:"reval";s:785:"<li><a href='http://ad.dedecms.com' target='_blank' title='DedeCMS广告'>DedeCMS广告</a></li><li><a href='http://service.dedecms.com' target='_blank' title='织梦客户服务中心'>
织梦客户服务中心</a></li><li><a href='http://ask.dedecms.com' target='_blank' title='织梦问答'>
织梦问答</a></li><li><a href='http://www.bufuzao.com' target='_blank' title='不浮躁'>
不浮躁</a></li><li><a href='http://tools.dedecms.com' target='_blank' title='站长工具'>
站长工具</a></li><li><a href='http://site.desdev.cn' target='_blank' title='DedeCMS建站中心'>
DedeCMS建站中心</a></li><li><a href='http://help.dedecms.com' target='_blank' title='织梦CMS帮助中心'>
织梦CMS帮助中心</a></li><li><a href='http://' target='_blank' title=''>
</a></li>";}s:7:"timeout";i:1472607884;}